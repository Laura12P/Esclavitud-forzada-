ALTER TABLE Historial_Musical
    ADD metadataSesion XMLTYPE;

 INSERT INTO Historial_Musical (
    idRegistro,
    fechaRegistro,
    notaPersonal,
    idCancion,
    idUsuario,
    metadataSesion
)
VALUES ( 0, SYSDATE, 'Sonó perfecta en el gym', 3, 1,
    XMLTYPE(
        '<?xml version="1.0" encoding="UTF-8"?>
         <sesion version="1.0">
             <dispositivo tipo="movil">iPhone 14</dispositivo>
             <calidad kbps="320">Alta</calidad>
             <contexto>Haciendo ejercicio</contexto>
             <duracion unidad="segundos">215</duracion>
         </sesion>'
    )
);
 
-- Segundo ejemplo: escucha desde escritorio, calidad baja
INSERT INTO Historial_Musical (
    idRegistro,
    fechaRegistro,
    notaPersonal,
    idCancion,
    idUsuario,
    metadataSesion
)
VALUES (0, SYSDATE, NULL, 1, 2, XMLTYPE(
        '<?xml version="1.0" encoding="UTF-8"?>
         <sesion version="1.0">
             <dispositivo tipo="escritorio">Windows PC</dispositivo>
             <calidad kbps="128">Normal</calidad>
             <contexto>Trabajando</contexto>
             <duracion unidad="segundos">243</duracion>
         </sesion>'
    )
);
 
COMMIT;

-- CONSULTAS DEL XML TYPE

SELECT
    idRegistro,
    idCancion,
    EXTRACTVALUE(metadataSesion, '/sesion/dispositivo') AS dispositivo,
    EXTRACTVALUE(metadataSesion, '/sesion/dispositivo/@tipo') AS tipo_dispositivo,
    EXTRACTVALUE(metadataSesion, '/sesion/calidad/@kbps') AS kbps,
    EXTRACTVALUE(metadataSesion, '/sesion/contexto') AS contexto,
    EXTRACTVALUE(metadataSesion, '/sesion/duracion') AS duracion_seg
FROM Historial_Musical
WHERE idUsuario = 1
  AND metadataSesion IS NOT NULL;
 
 
-- 5b. Filtrar escuchas realizadas desde dispositivo móvil
SELECT
    hm.idUsuario,
    hm.idCancion,
    hm.fechaRegistro,
    EXTRACTVALUE(hm.metadataSesion, '/sesion/contexto') AS contexto
FROM Historial_Musical hm
WHERE EXISTSNODE(
    hm.metadataSesion,
    '/sesion/dispositivo[@tipo="movil"]'
) = 1;

------ X-XMLTYPE-------
ALTER TABLE Historial_Musical DROP COLUMN metadataSesion;