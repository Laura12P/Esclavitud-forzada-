--------------------------------------------------------------------------------
---------------------------- PRUEBA DE ACEPTACIÓN ------------------------------
--------------------------------------------------------------------------------

------------------------------ Prueba de Samuel -------------------------------

-- 1. Registrar una nueva canción en el catálogo 
BEGIN
    PA_CATALOGO_CANCIONES.insertar_cancion(
        p_titulo => 'Generic Beats 2026',
        p_duracion => 180,
        p_año => TO_DATE('2026-01-15', 'YYYY-MM-DD'),
        p_idArtista => 1
    );
END;
/

-- 2. Confirmar consultando la última canción agregada automáticamente
DECLARE
    v_idCancion  Cancion.idCancion%TYPE;
    v_titulo     Cancion.tituloCancion%TYPE;
    v_duracion   Cancion.duracion%TYPE;
    v_año        Cancion.año%TYPE;
BEGIN
    -- Capturamos el ID más altopara realizar la verificación
    SELECT MAX(idCancion) INTO v_idCancion FROM Cancion;
    
    PA_CATALOGO_CANCIONES.consultar_cancion(
        p_idCancion => v_idCancion, 
        p_titulo    => v_titulo,
        p_duracion  => v_duracion,
        p_año       => v_año
    );
END;
/

-- 3. Insertar una publicación asociada a la canción creada 
DECLARE
    v_idCancion Cancion.idCancion%TYPE;
BEGIN
    SELECT MAX(idCancion) INTO v_idCancion FROM Cancion;
    
    PA_PUBLICACION.insertar_publicacion(
        p_contenido => 'Nueva publicación de prueba con el usuario genérico.',
        p_idUsuario => 1, -- Usamos tu usuario 1 ya existente
        p_idCancion => v_idCancion
    );
END;
/

-- 4. El usuario realiza una búsqueda en el sistema
BEGIN
    PA_BUSQUEDAS_USUARIO.insertar_busqueda(
        p_termino => 'Estudio Enfocado Lo-Fi',
        p_idUsuario => 1
    );
END;
/

-- 5. Crear una recomendación directa hacia otro usuario del sistema
DECLARE
    v_idCancion Cancion.idCancion%TYPE;
BEGIN
    SELECT MAX(idCancion) INTO v_idCancion FROM Cancion;
    
    PA_RECOMENDACION.insertar_recomendacion(
        p_mensaje => 'Te comparto este contenido musical.',
        p_tipo => 'directa', 
        p_idUsuario => 1,
        p_idCancion => v_idCancion,
        p_idDestino => 2 
    );
END;
/

-- 6. Modificar el entorno de privacidad y configuración del Usuario 1
BEGIN
    PA_CONFIGURACION_USUARIO.actualizar_configuracion(
        p_idUsuario => 1,
        p_perfilPublico => 0,
        p_quienPuedeSeguir => 'seguidores',
        p_quienVeHistorial => 'nadie',
        p_quienVePublicaciones => 'seguidores',
        p_notificaciones => 1
    );
END;
/

-- 7. Agregar una bloqueo a la lista negra
BEGIN
    PA_CONFIGURACION_USUARIO.agregar_bloqueo(
        p_idUsuario => 1,
        p_idUsuarioBloqueado => 3,
        p_motivo => 'Se pasó de grosero'
    );
END;
/

-- 8. Error: Registra recomendación con tipo que no existe
DECLARE
    v_idCancion Cancion.idCancion%TYPE;
BEGIN
    SELECT MAX(idCancion) INTO v_idCancion FROM Cancion;
    
    PA_RECOMENDACION.insertar_recomendacion(
        p_mensaje => 'Error esperado',
        p_tipo => 'invalida_tipo', 
        p_idUsuario => 1,
        p_idCancion => v_idCancion,
        p_idDestino => 2
    );
END;
/

-- 9. Confirmación final consultando el estado de los bloqueos mediante la vista de tu esquema
DECLARE
    v_conteo NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_conteo 
    FROM UsuariosBloqueados 
    WHERE idUsuario = 1;
END;
/

-- Y para revisar que en efecto, los datos ingresaron a la base de datos:
SELECT 
    U.idUsuario AS "ID",
    U.nombreUsuario AS "USUARIO",
    (SELECT COUNT(*) FROM Publicacion WHERE idUsuario = U.idUsuario) AS "TOTAL PUBLICACIONES",
    (SELECT COUNT(*) FROM HistorialBusqueda WHERE idUsuario = U.idUsuario) AS "BUSQUEDAS REALIZADAS",
    (SELECT COUNT(*) FROM ListaNegra WHERE idUsuario = U.idUsuario) AS "USUARIOS BLOQUEADOS",
    (SELECT COUNT(*) FROM Recomendacion WHERE idUsuarioRecomendador = U.idUsuario) AS "RECOMENDACIONES ENVIADAS",
    CU.quienVeHistorial AS "PRIVACIDAD HISTORIAL",
    CU.quienPuedeSeguir AS "PRIVACIDAD SEGUIDORES"
FROM Usuario U
LEFT JOIN ConfiguracionUsuario CU ON U.idUsuario = CU.idUsuario
WHERE U.idUsuario = 1;


------------------------- Prueba Laura -----------------------------------------
-- 1. Registrar el perfil del nuevo artista en el catálogo
BEGIN
    PA_CATALOGO_CANCIONES.insertar_artista(   
        p_nombre => 'The Cyberpunk Orchestra',
        p_pais => 'Japón',                
        p_añoDebut => TO_DATE('2023-01-15', 'YYYY-MM-DD')
    );
END;
/
 
 
-- 2. El artista registra una nueva canción vinculada a su perfil recién creado
DECLARE
    v_idArtista Artista.idArtista%TYPE;
BEGIN
    SELECT MAX(idArtista) INTO v_idArtista FROM Artista;
 
    PA_CATALOGO_CANCIONES.insertar_cancion(
        p_titulo => 'Neon Rain',
        p_duracion  => 245,
        p_año => TO_DATE('2025-05-17', 'YYYY-MM-DD'), 
        p_idArtista => v_idArtista
    );
END;
/
 
 
-- 3. Confirmar consultando la canción y sus atributos
DECLARE
    v_idCancion Cancion.idCancion%TYPE;
    v_titulo Cancion.tituloCancion%TYPE;
    v_duracion  Cancion.duracion%TYPE;
    v_año Cancion.año%TYPE;
BEGIN
    SELECT MAX(idCancion) INTO v_idCancion FROM Cancion;
 
    PA_CATALOGO_CANCIONES.consultar_cancion(
        p_idCancion => v_idCancion,
        p_titulo => v_titulo,
        p_duracion  => v_duracion,
        p_año => v_año
    );
END;
/
 
 
-- 4. Asignar el género musical a la nueva pista
DECLARE
    v_idCancion Cancion.idCancion%TYPE;
BEGIN
    SELECT MAX(idCancion) INTO v_idCancion FROM Cancion;
 
    PA_ADMIN_CONTENIDO_MUSICAL.asignar_genero_cancion( 
        p_idCancion => v_idCancion,
        p_idGenero  => 2
    );
END;
/
 
 
-- 5. El artista publica un post promocionando el lanzamiento
DECLARE
    v_idCancion Cancion.idCancion%TYPE;
BEGIN
    SELECT MAX(idCancion) INTO v_idCancion FROM Cancion;
 
    PA_PUBLICACION.insertar_publicacion(
        p_contenido => '¡Mi nuevo sencillo Neon Rain ya está disponible en Moodheard! Escúchenlo para máxima concentración.',
        p_idUsuario => 5,
        p_idCancion => v_idCancion
    );
END;
/
 
 
-- 6. Un fan descubre la canción y la escucha
DECLARE
    v_idCancion Cancion.idCancion%TYPE;
BEGIN
    SELECT MAX(idCancion) INTO v_idCancion FROM Cancion;
    INSERT INTO Historial_Musical (idRegistro, fechaRegistro, notaPersonal, idCancion, idUsuario)
    VALUES (0, SYSDATE, NULL, v_idCancion, 2);
 
    COMMIT;
END;
/
 
-- 7. Validar el estado del catálogo tras todos los pasos anteriores
SELECT
    A.idArtista AS "ID ARTISTA",
    A.nombre AS "NOMBRE ARTISTA",
    (SELECT COUNT(*) FROM Cancion WHERE idArtista = A.idArtista) AS "TOTAL PISTAS",
    C.tituloCancion AS "ÚLTIMO LANZAMIENTO",
    (SELECT COUNT(*) FROM Tiene_Genero WHERE idCancion = C.idCancion) AS "GÉNEROS ASOCIADOS",
    (SELECT COUNT(*) FROM Historial_Musical WHERE idCancion = C.idCancion)  AS "REPRODUCCIONES GLOBALES"
FROM Artista A
LEFT JOIN Cancion C ON A.idArtista = C.idArtista
WHERE A.idArtista = (SELECT MAX(idArtista) FROM Artista)
ORDER BY C.idCancion DESC;
 